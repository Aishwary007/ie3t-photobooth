import os
os.system("cp /home/rahul/capt0000.jpg /home/rahul/apache")
