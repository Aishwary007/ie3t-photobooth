import os
os.system('python pkill2.py &')
os.system("feh -t -x -Sfilename -E 750 -y 1400 -W 2000 capt0000.jpg")


