<!DOCTYPE html>
<html>
<head>
	<title>Photo Booth</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<style>
		body{
			background: url("img/background.png");
			background-repeat: no-repeat;
			
		}
	</style>
</head>
<body>
	<div class="row">
		<center>IEEE Automated Photobooth</center>
	</div>